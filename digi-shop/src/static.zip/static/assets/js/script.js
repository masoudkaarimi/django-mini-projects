import 'preline'
import './cart.js'

import "toastify-js/src/toastify.css"

document.addEventListener("DOMContentLoaded", function () {
    console.log("Document is ready");
});